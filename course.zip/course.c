/**
 * @file course.c
 * @author Yi Liu (liu981@mcmaster.ca)
 * @brief This file containes 4 function about the course. (enroll_student, print_course, top_student and passing)
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

///This function enrolls all of the students into the course. If there is only 1 student, then allocate a length of 1 in memory. If there is more than 1 student, then relocate a length of the number of student
/// @param course pointer to course
/// @param student pointer to student 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

///This function prints all the informaton about the course (including course name, course code, total student and every enrolled student)
/// @param course pointer to course
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

///This function can figure out the top student(with highest average grades) in the course by comparing every student's average grade
/// @param course pointer to course
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0; // set a initial student average 
  double max_average = average(&course->students[0]); //set the first student's average as the highest 
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average)  //comparing the average grades
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

///This function judge whether the student is passing a course (average greater than or equal to 50)
/// @param course pointer to course
/// @param total_passing pointer to the number of passing student
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++; //check if the average is greater than or equal to 50
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}