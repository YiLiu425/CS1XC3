var files_dup =
[
    [ "course", "dir_9ece3eaba545d8620afbd90a709bbfec.html", "dir_9ece3eaba545d8620afbd90a709bbfec" ]
];