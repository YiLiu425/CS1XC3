var struct__course =
[
    [ "code", "struct__course.html#a17e6787fbe54ae62b01802024bd1544d", null ],
    [ "name", "struct__course.html#aeaf846aa21a7d016a52f0b5b0c2f5544", null ],
    [ "students", "struct__course.html#a6a55cbd6c773bf306aaed7a9fe16ce1c", null ],
    [ "total_students", "struct__course.html#a6de820e9130cb18bb757b6f17df6c002", null ]
];