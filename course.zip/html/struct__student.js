var struct__student =
[
    [ "first_name", "struct__student.html#a320c6a52b4984cd8e24726d0a264574c", null ],
    [ "grades", "struct__student.html#aa6495523ad72007cf509e024603b4127", null ],
    [ "id", "struct__student.html#a8023cf989dfc5c3b8673f5ef9a5b126d", null ],
    [ "last_name", "struct__student.html#a48ed726bdb658f3f3e16a5ab1cd0f87a", null ],
    [ "num_grades", "struct__student.html#aede90734d1fafb541757aa6934618a33", null ]
];