/**
 * @file course.h
 * @author Yi Liu (liu981@mcmaster.ca)
 * @brief This file defined a new data type structure called Course (with 4 members) and declares the function which are defined in the file course.c
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "student.h"
#include <stdbool.h>
 
/// \brief This defined a new data type structure with 4 members: name, code, students, total_students


typedef struct _course 
{
  char name[100]; /**< this member is a char with a max length of 100 meaning the name of the course */
  char code[10];  /**< this member is a char with a max length of 10 meaning the code of the course */
  Student *students;  /**< this member is a Student which is defined in the file student.h */
  int total_students; /**< this member is a int meaning the total number of students */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


