/**
 * @file student.h
 * @author Yi Liu (liu981@mcmaster.ca)
 * @brief This file defined a new data type structure called Student(with 4 members) and declares the function which are defined in the file student.c
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/// \brief This defined a new data type structure which contains 5 members.

typedef struct _student
{ 
  char first_name[50]; /**< this member is a char with a max length of 50 meaning the student's first name */
  char last_name[50];  /**< this member is a char with a max length of 50 meaning the student's last name */
  char id[11];    /**< this member is a char with a max length of 11 meaning the student's ID */
  double *grades; /**< this member is a double meaning the student's grade */
  int num_grades; /**< this member is a double meaning the student's number of grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
